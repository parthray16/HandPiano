# HandPiano
Computer Vision Final Project

To Run:
  pip install -r requirements.txt
  python ./HandPiano.py
